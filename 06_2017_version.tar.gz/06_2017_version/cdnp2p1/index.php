<?php require_once("top.php") ?>
<h2>Welcome to Content Distribution Trade site!</h2>
<p>In this site, you can sign up to help transmit contents of large sites and earn your
rewards. </p>
<?php require_once("bottom.php") ?>