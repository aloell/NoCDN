//document.open();
document.write("<html><body>a totally new page!</body></html>");
